var name = prompt ('Your name','');
document.write("<CENTER><Strong><FONT FACE=ARIAdL,VERDANA  SIZE=5>Welcome "+name+"</FONT><Strong></CENTER>")
var array=[];
// function add()
// {
//     var value1= parseInt(document.getElementById("numberA").value);
//     var value2=parseInt(document.getElementById("numberB").value);
//     var sum=value1+value2;
//     document.getElementById("result").value=sum;

// }

// function substract()
// {
//     var value1= parseInt(document.getElementById("numberA").value);
//     var value2=parseInt(document.getElementById("numberB").value);
//     var subtraction=value1-value2;
//     document.getElementById("result").value=subtraction;

// }

// function multiply()
// {
//     var value1= parseInt(document.getElementById("numberA").value);
//     var value2=parseInt(document.getElementById("numberB").value);
//     var multiplication=value1*value2;
//     document.getElementById("result").value=multiplication;

// }

// function divide()
// {
//     var value1= parseInt(document.getElementById("numberA").value);
//     var value2=parseInt(document.getElementById("numberB").value);
//     var devision=value1/value2;
//     document.getElementById("result").value=devision;

// }
function myFunction(id)
{
    var value1= parseInt(document.getElementById("numberA").value);
    var value2=parseInt(document.getElementById("numberB").value);
    var res;
    if(id=="add"){
        res=value1+value2;
        document.getElementById("result").value=res;
        array.push(res);
    }
    else if(id=="substract"){
        res=value1-value2;
        document.getElementById("result").value=res;
        array.push(res);
    }
    else if(id=="multiply"){
        res=value1*value2;
        document.getElementById("result").value=res;
        array.push(res);
    }
    else if(id=="divide"){
        res=value1/value2;
        document.getElementById("result").value=res;
        array.push(res);
    }
}
function PrintArray()
{
    document.getElementById('Results').innerHTML =array;
}

/*
const firstarray = ["John", "Jason", "Kevin"];
firstarray.unshift("Jad");

const secondarray = ["Manel", "Nahla", "Sabine", "Mirna"];

const thirdarray;

thirdarray = firstarray.concat(secondarray);

(console): Array(7) [ "John", "Jason", "Kevin", "Manel", "Nahla", "Sabine", "Mirna" ]

thirdarray.indexOf("John"); //return index in third array

(console): 0

thirdarray.length(); //return the length of the array; number of elements 

(console): 7

thirdarray.pop(); //removes Mirna from thirdarray

(console): "Mirna" Array(6) [ "John", "Jason", "Kevin", "Manel", "Nahla", "Sabine" ]

thirdarray.shift(); //removes John from thirdarray

"John" Array(5) [ "Jason", "Kevin", "Manel", "Nahla", "Sabine" ]

thirdarray.push("Diva"); //adds an element Diva to the end of thirdarray

(console): 6

thirdarray.reverse(); //reverse the order of elements in thirdarray

(sonsole): Array(6) [ "Diva", "Sabine", "Nahla", "Manel", "Kevin", "Jason" ]

const save = thirdarray.slice(0,3);
Array(3) [ "Diva", "Sabine", "Nahla" ]

fortharray.includes("Sabine");
true
*/ 